from micromantid import *

class UsageService():
    @staticmethod
    def registerFeatureUsage(*args, **kwargs):
        pass
