class InterfaceManager():
    @staticmethod
    def showCustomInterfaceHelp(name, genre):
        pass
