class MainView(object):
    def __init__(self):
        pass

    def get_presenter(self):
        pass

    def is_energy_conversion_allowed(self):
        pass

    def get_cut_algorithm(self):
        pass
