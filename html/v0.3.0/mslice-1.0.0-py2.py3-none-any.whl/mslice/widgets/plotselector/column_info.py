from enum import IntEnum


class Column(IntEnum):
    Number = 0
    Name = 1
    LastActive = 2
