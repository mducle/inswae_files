"""
Colour-map related functionality
"""

ALLOWED_CMAPS = ["viridis", "jet", "summer", "winter", "coolwarm"]
DEFAULT_CMAP = ALLOWED_CMAPS[0]
